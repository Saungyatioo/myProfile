package javafxml_package;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class MainPageController implements Initializable {

    @FXML
    private ChoiceBox<String> CarTypeID;
    @FXML
    private ChoiceBox<String> ColorID;
    @FXML
    private RadioButton ThreeInsuranceID;
    @FXML
    private ToggleGroup Insurance_Group;
    @FXML
    private RadioButton OneInsuranceID;
    @FXML
    private RadioButton NoInsuranceID;
    @FXML
    private TextArea DescriptionID;
    @FXML
    private Text PriceID;
    @FXML
    private Button ExitID;
    @FXML
    private ImageView ImageID;
    @FXML
    private CheckBox LocksID;
    @FXML
    private CheckBox WindowsID;
    @FXML
    private CheckBox AirID;
    
    private double price = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        CarTypeID.getItems().addAll("Toyota", "Lamborghini", "Ferrari");
        CarTypeID.setValue("Toyota"); 
        updateColorChoiceBoxAndDefaultFeatures();       
        CarTypeID.setOnAction(e -> {
            updateColorChoiceBoxAndDefaultFeatures(); 
            updateDescriptionAndPrice(); 
        });
        ColorID.setOnAction(e -> updateDescriptionAndPrice());
        Insurance_Group.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            updateDescriptionAndPrice();
        });
        LocksID.setOnAction(e -> updateDescriptionAndPrice());
        WindowsID.setOnAction(e -> updateDescriptionAndPrice());
        AirID.setOnAction(e -> updateDescriptionAndPrice());
    
        updateDescriptionAndPrice();
    }


    private void updateColorChoiceBoxAndDefaultFeatures() {
        String selectedCar = CarTypeID.getValue();
        ColorID.getItems().clear();
        switch (selectedCar) {
            case "Toyota" -> {
                ColorID.getItems().addAll("White", "Black", "Silver");
                LocksID.setSelected(true); 
                AirID.setSelected(false);
                WindowsID.setSelected(false);
                ImageID.setImage(new Image("Images/Toyota_White.png"));
                
                LocksID.setDisable(false);
                WindowsID.setDisable(false);
                AirID.setDisable(true);
            }
            case "Lamborghini" -> {
                ColorID.getItems().addAll("Yellow", "Green", "Orange");
                AirID.setSelected(true); 
                WindowsID.setSelected(false);
                LocksID.setSelected(false);
                ImageID.setImage(new Image("Images/Lambo_Yellow.png"));
                
                LocksID.setDisable(false);
                WindowsID.setDisable(true);
                AirID.setDisable(false);
            }
            case "Ferrari" -> {
                ColorID.getItems().addAll("Red", "Black", "White");
                WindowsID.setSelected(true); 
                LocksID.setSelected(false);
                AirID.setSelected(false);
                ImageID.setImage(new Image("Images/Ferrari_Red.png"));
                
                LocksID.setDisable(true);
                WindowsID.setDisable(false);
                AirID.setDisable(false);
            }
        }
        ColorID.setValue(ColorID.getItems().get(0));
    }

    private void updateDescriptionAndPrice() {
        DescriptionID.clear(); 
        String selectedCar = CarTypeID.getValue();
        price = getPriceForCarType(selectedCar);
        String selectedColor = ColorID.getValue();
    
        DescriptionID.appendText("Car: " + selectedCar + "\n");
        DescriptionID.appendText(getCarNotes(selectedCar) + "\n");
        DescriptionID.appendText("Color: " + selectedColor + "\n");
    
        if (ThreeInsuranceID.isSelected()) {
            DescriptionID.appendText("Insurance: Three year warranty\n");
            price += 0.25 * price;
        } else if (OneInsuranceID.isSelected()) {
            DescriptionID.appendText("Insurance: One year warranty\n");
            price += 0.1 * price;
        } else {
            DescriptionID.appendText("Insurance: None\n");
        }
    
        DescriptionID.appendText("Optional: ");
        if (LocksID.isSelected()) {
            DescriptionID.appendText(" Power Locks ");
            price += 500.0;
        }
        if (WindowsID.isSelected()) {
            DescriptionID.appendText(" Power Windows ");
            price += 700.0;
        }
        if (AirID.isSelected()) {
            DescriptionID.appendText(" Air-conditioning ");
            price += 2500.0;
        }

        PriceID.setText("$" + price);
    }
    
    private String getCarNotes(String carType) {
        return switch (carType) {
            case "Toyota" -> "Toyota cars offer a little something for everyone.\n From sporty designs and chic lines to cutting-edge\n connectivity and safety features, Toyota car\n models help you blaze your own trail.";
            case "Lamborghini" -> "The authentic design masterpieces together\n stark dynamism with aggression to produce a cutting edge\n carbon fiber monocoque. The interior of the Aventador\n combines high-level technology and luxury equipment\n with premium-quality materials, skilfully crafted with\n the expertise characteristic of the finest Italian traditions.";
            case "Ferrari" -> "Ferrari S.A. is an Italian luxury sports car\n manufacturer based in Maranello, Italy. Founded by\n Enzo Ferrari in 1939 out of the Alfa Romeo race division\nas Auto Avio Costruzioni, the company built its first car\nin 1940, and produced its first Ferrari-badged car in 1947.";
            default -> "";
        };
    }
    
    private double getPriceForCarType(String carType) {
        return switch (carType) {
            case "Toyota" -> 25000.0;
            case "Lamborghini" -> 155000.0;
            case "Ferrari" -> 300000.0;
            default -> 0;
        };
    }

    @FXML
    private void onClickExit(ActionEvent event) {
        DescriptionID.setText("");

        LocksID.setSelected(false);
        WindowsID.setSelected(false);
        AirID.setSelected(false);

        ThreeInsuranceID.setSelected(false);
        OneInsuranceID.setSelected(false);
        NoInsuranceID.setSelected(false);
    
        // Clear the PriceID
        PriceID.setText("");
    }
}
