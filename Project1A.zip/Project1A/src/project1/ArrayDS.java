package project1;

public class ArrayDS<T> implements SequenceInterface<T>, ReorderInterface {
    private final BagInterface<Integer>[][] array; //the underlying 2-D array
    private int size; //the number of items in the sequence
    private T[] alphabet; //the possible item values (e.g., the decimal digits)
    private T firstItem; //the first item in the sequence
    private T lastItem; //the last item in the sequence

    @SuppressWarnings("unchecked")
    public ArrayDS(T[] alphabet){ //constructor
        // create an array with the same size of alphabet        
        array = new ResizableArrayBag[alphabet.length][alphabet.length];
        
        for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                array[i][j] = new ResizableArrayBag<>();
            }
        }
        this.alphabet = alphabet;
        this.size = 0;
    }
    
//    The second constructor (called a “copy constructor”) initializes 
//    the ArrayDS object as a copy of the argument (inserting all of the 
//    items inside the arrays in the argument object to the corresponding 
//    arrays in the new object).

    public ArrayDS(ArrayDS<T> other){
        this.alphabet = other.alphabet; 
        this.size = other.size;
        this.firstItem = other.firstItem;
        this.lastItem = other.lastItem;
        array = new ResizableArrayBag[alphabet.length][alphabet.length];

        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet.length; j++) {
                array[i][j] = new ResizableArrayBag<>();
                if (!other.array[i][j].isEmpty()) {
                    BagInterface<Integer> newBag = new ResizableArrayBag<>(); 
                    BagInterface<Integer> newBag2 = new ResizableArrayBag<>();
                    for (int a = 0; a < other.array[i][j].getCurrentSize(); a++) {  
                        var temp = other.array[i][j].remove();
                        newBag.add(temp);  
                        newBag2.add(temp);
                    }
                    other.array[i][j] = newBag2;
                    array[i][j] = newBag;
                }
            }
        }
    }
    
    /* This method will return a String that is the concatenation of all of the
    itmes in the Sequence implemented by the ArrayDS object apended together without spaces.
    For example, if an ArrayDS object contains the number 1,2,3,4,5,6, toString()
    should ouptut 123456.*/
    @Override
    public String toString(){
        if (size == 0) return "";
        StringBuilder result = new StringBuilder();
        result.append(firstItem);
        if (size == 1) return result.toString();
        
        int position = 1;
        while(position < size) {
            result.append(findItemAt(position));
            position++;
        }
        return result.toString();
    }
    
    private String findItemAt(int pos) {
        if (pos == 0) {
            return firstItem.toString();
        }

        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet.length; j++) {
                if (!array[i][j].isEmpty()) {
                    BagInterface<Integer> tempBag = new ResizableArrayBag<>();
                    boolean found = false;
                    while (!array[i][j].isEmpty()) {
                        Integer item = array[i][j].remove();
                        if (item == pos) {
                            found = true;
                            tempBag.add(item); 
                            break;  
                        }
                        tempBag.add(item);  
                    }
                    while (!tempBag.isEmpty()) {
                        array[i][j].add(tempBag.remove());
                    }
                    if (found) {
                        return alphabet[j].toString(); 
                    }
                }
            }
        }
        return "";  
    }

    /** Add a new Object to the logical end of the SequenceInterface<T>
	 * @param item the item to be added.
	 */
    @Override
    public void append(T item){
       if (firstItem == null) {
           firstItem = item;
           lastItem = item;
           size++;
           return;
       }
       array[indexInAlphabet(lastItem)][indexInAlphabet(item)].add(size);
       size++;
       lastItem = item;
    }

	/** Add a new Object to the logical start of the SequenceInterface<T>
	 * @param item the item to be added.
	 */
    @Override
    public void prefix(T item) {
        if (size == 0) {
           firstItem = item;
           lastItem = item;
           size++;
           return;         
        } if (size == 1) {
            size++;
            array[indexInAlphabet(item)][indexInAlphabet(firstItem)].add(1);
            firstItem = item;
            return;
        }
       for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                if (!array[i][j].isEmpty()){
                    //make a new bag
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();                   
                    for (int a=0; a < array[i][j].getCurrentSize();a++){
                        var temp = array[i][j].remove();
                        temp++;
                        newBag.add(temp);                        
                    }
                    array[i][j] = newBag;
                }
            }
        }
       size++;
       array[indexInAlphabet(item)][indexInAlphabet(firstItem)].add(1);
       firstItem = item;
    }

	/** Delete the item at the logical start of the SequenceInterface<T>
	* @return the deleted item
	* @throws EmptySequenceException if the sequence is empty
	*/
    @Override
    public T deleteHead() {
        if (size == 0) 
            throw new EmptySequenceException("sequence empty");
        T deletedItem = firstItem;
        boolean found = false;
        for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                if (!array[i][j].isEmpty()) {
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();   
                    for (int a = 0; a < array[i][j].getCurrentSize(); a++) {
                        var temp = array[i][j].remove();
                            newBag.add(temp - 1);
                            if (temp == 1)
                                firstItem = alphabet[j];
                    }
                    array[i][j] = newBag;
                }
            }
        }
        if (deletedItem != null)
            size--;
        return deletedItem;
        
    }
    
	/** Delete the item at the logical end of the SequenceInterface<T>
	 * @return the deleted item
	 * @throws EmptySequenceException if the sequence is empty
	 */
    @Override
    public T deleteTail(){
        if (size == 0) 
            throw new EmptySequenceException("sequence empty");
        T deletedItem = lastItem;
        for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                if (!array[i][j].isEmpty()) {
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();   
                    for (int a = 0; a < array[i][j].getCurrentSize();a++){
                        var temp = array[i][j].remove();
                        if (temp != size - 1) {
                            newBag.add(temp);
                        } else {
                            lastItem = alphabet[i];
                        }              
                    }
                    array[i][j] = newBag;
                }
            }
        }
        if (deletedItem != null){
            size--;
        }
        return deletedItem;
        
    }

	/**
	 * @return true if the SequenceInterface is empty, and false otherwise
	 */
    @Override
    public boolean isEmpty(){
        
        return size == 0;
        
    }

	/**
	 * @return the number of items currently in the SequenceInterface
	 */
    @Override
    public int size(){
        
        return size;
        
    }

	/**
	 * @return the the logically first item in the sequence
	 */
    @Override
    public T first(){
        
        return firstItem;
        
    }

	/**
	 * @return the the logically last item in the sequence
	 */
    @Override
    public T last(){
        
        return lastItem;
        
    }

	/** Checks if a given sequence is a subsequence of this sequence
	 * @param another the sequence to check
	 * @return true if another is a subsequence of this sequence or false otherwise
	 */
    @Override
    public boolean hasSubsequence(SequenceInterface<T> another){
        int position = 0;
        int index = 0;
        while(position < size) {
            System.out.println(index);
            if (findItemAt(position).equals(another.itemAt(index))) {
                index++;
            }               
            else {
                index = 0;
            }
            if (index == another.size()){
                return true;
            }
            position++;
        }
        
        return false;
    }

	/** Check if a given item comes right before another given item in the sequence
	 * @param first an item
	 * @param second another item
	 * @return true if first comes right before second in the sequence, or false otherwise
	 */
    @Override
    public boolean predecessor(T first, T second){
        int firstIndex = indexInAlphabet(first);
        int secondIndex = indexInAlphabet(second);
        if (array[firstIndex][secondIndex].getCurrentSize() != 0){
            return true;
        }
        return false;
            
    }

	/** Return the number of occurences in the sequence of a given item
	 * @param item an item
	 * @return the number of occurences in the sequence of item
	 */
    @Override
    public int getFrequencyOf(T item){
        int frequency = 0;
        int index = indexInAlphabet(item);
        
        for (int row = 0; row < alphabet.length; row++){
            frequency+=array[row][index].getCurrentSize();
        }
        
        for (int col = 0; col < alphabet.length; col++){
            if(col == index){
                continue;
            }
            frequency+=array[index][col].getCurrentSize();          
        }           
        return frequency;
            
    }

	/** Reset the SequenceInterface to empty status by reinitializing the variables
	 * appropriately
	 */
    @Override
    public void clear(){
        for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                for (int a = 0; a < array[i][j].getCurrentSize(); a++) {
                    var temp = array[i][j].remove();
                }
            }
        }
        size = 0; 
        firstItem = null; 
        lastItem = null;
    }

	/** Return the item at a given logical position
	 * @param position the logical position starting from 0
	 * @return the item at logical position position
	 * @throws IndexOutOfBoundsException if position < 0
	                                     or position > size()-1
	 */
    @Override
    public T itemAt(int position){
        if (position < 0 || position > size()-1){
            throw new IndexOutOfBoundsException("index out of bounds");    
        } 
        if (position == 0) {
            return firstItem;
        }
        T item = null;
        boolean found = false;
        for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                
                if (!array[i][j].isEmpty()) {
                    
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();   
                    for (int a = 0; a < array[i][j].getCurrentSize();a++){
                        
                        var temp = array[i][j].remove();
                        if (temp == position) {
                            if (position == 3)
                    System.out.println("here");
                            item = alphabet[j];
                            found = true;
                        }
                        newBag.add(temp);                                                
                    }
                    array[i][j] = newBag;
                    if (found) return item;
                }
            }
        }
        
        return item;            
    }

	/** Return an array containing the items in the sequence in their logical order
	 * @return the an array containing the items in the sequence in their logical order
	 *         or null if the sequence is empty
	 */    
  	@Override
    public T[] toArray(){
        T[] result = (T[]) new Object[size()];
        result[0] = firstItem;
        for (int i = 0; i < alphabet.length; i++){
            for(int j = 0; j < alphabet.length; j++){
                if (!array[i][j].isEmpty()) {                    
                    //make a new bag
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();
                    while (!array[i][j].isEmpty()){
                        var temp = array[i][j].remove();
                        result[temp] = alphabet[j];
                        newBag.add(temp);
                    }
                    while (!newBag.isEmpty()){
                        array[i][j].add(newBag.remove());
                    }
                }
            }
        }
        return result;           
    }

	/** Return the logical position in the sequence of the first occurrence of a given item
	 * @param item an item
	 * @return the logical position in the sequence of the first occurrence of item
	 *         or -1 if the item doesn't exist
	 */
    @Override
    public int firstOccurrenceOf(T item){
        int rowIndex = indexInAlphabet(item);
        for (int col = 0; col < alphabet.length; col++) {
            if (!array[rowIndex][col].isEmpty()) {
                    //make a new bag
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();   
                    for (int a = 0; a < array[rowIndex][col].getCurrentSize();a++){
                        var temp = array[rowIndex][col].remove();
                        if (temp == 1) return 0;
                        newBag.add(temp);                                                
                    }
                    array[rowIndex][col] = newBag;
                }
        }
        int min = size;
        int colIndex = indexInAlphabet(item);
        for (int row = 0; row < alphabet.length; row++) {
            if (!array[row][colIndex].isEmpty()) {
                    //make a new bag
                    BagInterface<Integer> newBag = new ResizableArrayBag<>();   
                    for (int a = 0; a < array[row][colIndex].getCurrentSize();a++){
                        var temp = array[row][colIndex].remove();
                        min = Math.min(temp, min);
                        newBag.add(temp);                                                
                    }
                    array[row][colIndex] = newBag;
                }
        }
        return (min == size) ? -1 : min;           
    }

	/** Return the index of a given item in the alphabet of the sequence
	 * @param item an item
	 * @return the index of item in the alphabet of the sequence
	 *         or -1 if the item doesn't exist
	 */
    @Override
    public int indexInAlphabet(T item){
        for (int i = 0; i < alphabet.length; i++){
            if (alphabet[i].equals(item)){
                return i;
            }
        }
        return -1;            
    }

	/** Return the index in the alphabet of the next item in the sequence
	 * after the occurrence of item at position
	 * @param item an item
	 * @param position item's position
	 * @return the index in the alphabet of the item after the occurrence of item
	 *         at position
	 *         or -1 if the next item doesn't exist
	 */
    @Override
    public int nextIndex(T item, int position){
        int col = indexInAlphabet(item);
        boolean found = false;
        for (int row = 0; row < alphabet.length; row++) {
            if (!array[row][col].isEmpty()) {
                BagInterface<Integer> newBag = new ResizableArrayBag<>();
                for (int a = 0; a < array[row][col].getCurrentSize(); a++) {
                    var temp = array[row][col].remove();
                    if (temp == position) 
                        found = true;                    
                    newBag.add(temp);
                } 
                array[row][col] = newBag;
            }
            if (found) break;
        }
        
        int row = indexInAlphabet(item);
        int index = -1;
        for (int column = 0; column < alphabet.length; column++) {
            if (!array[row][column].isEmpty()) {
                BagInterface<Integer> newBag = new ResizableArrayBag<>();
                for (int a = 0; a < array[row][column].getCurrentSize(); a++) {
                    var temp = array[row][column].remove();
                    if (temp == position + 1) 
                        index = column;                    
                    newBag.add(temp);
                } 
                array[row][column] = newBag;
            }
            if (index != -1) break;
        }
        return index;
                
    }
  
	/** Return the index in the alphabet of the previous item in the sequence
	 *  before the occurrence of item at position
	 * @param item an item
	 * @param position item's position
	 * @return the index in the alphabet of the item before the occurrence of item
	 *         at position
	 *         or -1 if the previous item doesn't exist
	 */
    @Override
    public int prevIndex(T item, int position){
        int col = indexInAlphabet(item);
        int rowIndex = -1;
        
        
        for (int row = 0; row < alphabet.length; row++) {
            if (!array[row][col].isEmpty()) {
                BagInterface<Integer> newBag = new ResizableArrayBag<>();
                for (int a = 0; a < array[row][col].getCurrentSize(); a++) {
                    var temp = array[row][col].remove();
                    if (temp == position)
                        rowIndex = row;
                    newBag.add(temp);
                } 
                array[row][col] = newBag;
            }
            if (rowIndex != -1) break;
        }
        return rowIndex;       
    }
    
    /** Logically reverse the data in the ReorderInterface object so that the item
	 * that was logically first will now be logically last and vice
	 * versa.  The physical implementation of this can be done in
	 * many different ways, depending upon how you actually implemented
	 * your physical ArrayDS<T> class
	 */
     @Override
    public void reverse(){
        BagInterface<Integer> tempBag = new ResizableArrayBag<>();
        while (!isEmpty()){
            tempBag.add((Integer) deleteTail());
        }
        BagInterface<Integer> newBag = new ResizableArrayBag<>();
        while (!tempBag.isEmpty()){
            T item = (T) tempBag.remove();
            prefix(item);
            newBag.add((Integer) item);
        }  
    }

	/** Remove the logically last item and put it at the
	 * front.  As with reverse(), this can be done physically in
	 * different ways depending on the underlying implementation.
	 */
    @Override
    public void rotateRight(){
        if (size > 1){
            T last = deleteTail();
            prefix(last);
        }
        
    }

	/** Remove the logically first item and put it at the
	 * end.  As above, this can be done in different ways.
	 */
    @Override
    public void rotateLeft(){
        if (size > 1){
            T first = deleteHead();
            append(first);
        }
    }
    	
}