package project1b;

/** A partial implementation of the ReallyLongInt class.
 * @author Sherif Khattab (Adapted from Dr. John Ramirez's Spring 2017 CS 0445 Assignment 2 code)
 * You need to complete the implementation of the remaining methods.  Also, for this class
 *  to work, you must complete the implementation of the ArrayDS class. See additional comments below.
 */

public class ReallyLongInt extends ArrayDS<Integer> implements Comparable<ReallyLongInt>
{
	// Instance variables are inherited.  You may not add any new instance variables
	private static final Integer[] DIGITS = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

	private ReallyLongInt(int size) {

		super(DIGITS);
		for (int i = 0; i < size; i++) {
			append(0);
		}
	}

	/**
	 * @param s a string representing the integer (e.g., "123456") with no leading
	 * zeros except for the special case "0".
	 * Note that we are adding the digits here to the END. This results in the
	 * MOST significant digit first. It is assumed that String s is a valid representation of an
	 * unsigned integer with no leading zeros.
	 * @throws NumberFormatException if s contains a non-digit
	 */
	public ReallyLongInt(String s)
	{
		super(DIGITS);
		char c;
		Integer digit;
		// Iterate through the String, getting each character and converting it into
		// an int.  Then add at the end.  Note that
		// the append() method (from ArrayDS) adds at the end.
		for (int i = 0; i < s.length(); i++)
		{
			c = s.charAt(i);
			if (('0' <= c) && (c <= '9'))
			{
				digit = c - '0';
				append(digit);
			}
			else
				throw new NumberFormatException("Illegal digit " + c);
		}
	}

	/** Simple call to super to copy the items from the argument ReallyLongInt into a new one.
	 * @param rightOp the object to copy
	 */
	public ReallyLongInt(ReallyLongInt rightOp)
	{
		super(rightOp);
	}

	// You must implement the methods below.  See the descriptions in the
	// assignment sheet

//	public ReallyLongInt add(ReallyLongInt rightOp) {
//// STEP ONE: Create a result bag
//// STEP TWO: Create carry, sum, this.index,  other.index
//// this.size() - 1, other.size() -1
//// sum: add everything from the current value that you're asked
//// STEP THREE: LOOP THROUGH while (this.index > 0 || other.index > 0 || carry>0
//// STEP FOUR: sum = carry
//// STEP FIVE: sum += itemAt(this otherIndex)
//// if sum >= 10, carry = 1
//// result prefix (sum % 10);

        public ReallyLongInt add(ReallyLongInt rightOp) {
            String thisStr = this.toString(); 
            String rightOpStr = rightOp.toString();  
            StringBuilder result = new StringBuilder();
            int carry = 0;
            int thisIndex = thisStr.length();
            int otherIndex = rightOpStr.length();
            while (thisIndex > 0 || otherIndex > 0 || carry > 0) {
                int digit1 = 0;
                int digit2 = 0;
                if (thisIndex > 0) {
                    thisIndex--;
                    digit1 = Integer.parseInt(String.valueOf(thisStr.charAt(thisIndex)));  
                }
                if (otherIndex > 0) {
                    otherIndex--;
                    digit2 = Integer.parseInt(String.valueOf(rightOpStr.charAt(otherIndex)));
                }
                int sum = digit1 + digit2 + carry;
                carry = sum / 10;
                result.append(sum % 10);
            }
            return new ReallyLongInt(result.reverse().toString());
        }

	public ReallyLongInt subtract(ReallyLongInt rightOp) {
            if (this.compareTo(rightOp) < 0) {
                throw new ArithmeticException("Invalid Difference -- Negative Number");
            }
            String thisStr = new StringBuilder(this.toString()).reverse().toString();  // Reverse first
            String rightOpStr = new StringBuilder(rightOp.toString()).reverse().toString();  // Reverse first
            StringBuilder result = new StringBuilder();
            int borrow = 0;
            int thisIndex = 0;
            int otherIndex = 0;
            while (thisIndex < thisStr.length() || otherIndex < rightOpStr.length()) {
                int digit1 = 0;
                int digit2 = 0;
                if (thisIndex < thisStr.length()) {
                    digit1 = Integer.parseInt(String.valueOf(thisStr.charAt(thisIndex)));
                    thisIndex++;
                }
                if (otherIndex < rightOpStr.length()) {
                    digit2 = Integer.parseInt(String.valueOf(rightOpStr.charAt(otherIndex)));
                    otherIndex++;
                }
                digit1 -= borrow;
                if (digit1 < digit2) {
                    digit1 += 10;
                    borrow = 1;
                } else {
                    borrow = 0;
                }
                int difference = digit1 - digit2;
                result.append(difference);
            }
            result.reverse();
            while (result.length() > 1 && result.charAt(0) == '0') {
                result.deleteCharAt(0);  
            }
            return new ReallyLongInt(result.toString());
        }

        /*Defined the way we expect compareTo to be. Remember that if one number 
        has more digits than the other, then clearly it is bigger (since there 
        are no leading 0s). Otherwise, the numbers must be compared digit by 
        digit.*/
        @Override
        public int compareTo(ReallyLongInt rOp) {
            String thisStr = this.toString();
            String rOpStr = rOp.toString();
            if (thisStr.length() != rOpStr.length()) {
                return thisStr.length() > rOpStr.length() ? 1 : -1;
            }
            int result = thisStr.compareTo(rOpStr);
            if (result > 0) {
                return 1;  
            } else if (result < 0) {
                return -1;  
            } else {
                return 0;  
            }
        }

        /*Defined the way we expect equals to be defined for objects – comparing 
        the data and not the reference. Don't forget to cast rightOp to 
        ReallyLongInt so that its array can be accessed (note: the argument 
        is an Object rather than ReallyLongInt because we are overriding 
        equals() from the version defined in class Object). Note: This method
        can easily be implemented once compareTo() has been completed.*/
	@Override
        public boolean equals(Object rightOp) {
            if (rightOp == null) {
                return false;
            }
            ReallyLongInt rOp = (ReallyLongInt) rightOp;
            return this.compareTo(rOp) == 0;
        }


        /*Return the result of multiplying the current ReallyLongInt by 10num 
        (10^num). Note that this can be done very simply through adding 0's.*/
        public ReallyLongInt multTenToThe(int num){
            String numString = this.toString(); 
            for (int i = 0; i < num; i++) {
                numString += "0";  
            }
            return new ReallyLongInt(numString);
	}

        /*Return the result of dividing the current ReallyLongInt by 10num 
        (10^num). Note that this can be done very simply through shifting. 
        Since 10num and our ReallyLongInt are both integers, make sure to 
        use integer division!*/
	public ReallyLongInt divTenToThe(int num){
            ReallyLongInt result = new ReallyLongInt(this);
            for (int i = 0; i < num; i++) {
                result.deleteTail(); 
            }
            result.removeZeros();
            return result;
	}

	/** Remove leading zeros.
	 *
	 */
	private void removeZeros(){
            while (this.size() > 1 && this.first().equals(0)){
                this.deleteHead();
            }
	}
}

 